/**
 * ClassName: ${CLASS_NAME} <br/>
 * Description: ${CLASS_NAME} <br/>
 * Date: ${YEAR}-${MONTH}-${DAY} ${TIME} <br/>
 * <br/>
 * @project ${PROJECT_NAME}
 * @package ${PACKAGE_NAME}
 * @author yufengming
 * @email yufengming@travelsky.com
 * <p>
 * 修改记录
 * @version 产品版本信息 ${YEAR}-${MONTH}-${DAY} ${TIME} yufengming(yufengming@travelsky.com) 新建<br/>
 */