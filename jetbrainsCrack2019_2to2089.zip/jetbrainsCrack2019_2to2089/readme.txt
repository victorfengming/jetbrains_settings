﻿1. 本补丁通杀全系列程序，在Bin目录找到程序名称.exe.vmoptions文件，
例如，idea的文件名为：idea64.exe.vmoptions，PHPstorm的文件名为：phpstorm64.exe.vmoptions
2. 打开文件，在末尾添加如下代码：
-javaagent:补丁位置\jetbrainsCrack.jar
补丁文件在本目录“jetbrainsCrack.jar”文件，将本文件复制到软件bin目录即可【其他地方也行】

3. 如果出现激活码非法的话，要修改C:\Users\你的用户名\.IntelliJIdea2019.2\config目录下的.vmoptions才行,重复2步骤

可以使用绝对地址也可以使用相对地址，注意，在Linux和MAC中，如果使用相对地址，快捷方式运行的程序可能打不开，如果存在打不开的情况，就要写补丁的绝对地址了。

4. 修改文件后，运行程序，选择注册，复制激活代码里面的内容即可。输入方式见图片。

github:victorfengming

https://blog.csdn.net/qq_40223983